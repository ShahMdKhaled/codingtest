package com.noorsoftsolution.chalucholo.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.noorsoftsolution.chalucholo.R
import com.noorsoftsolution.chalucholo.data.Booking

class BookingAdapter(private val bookingList: List<Booking>) :RecyclerView.Adapter<BookingAdapter.ViewHolder>()  {


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val id: TextView = itemView.findViewById(R.id.booking_id)
        val name: TextView = itemView.findViewById(R.id.name)
        val bookingDate: TextView = itemView.findViewById(R.id.bookingDate)
        val status: TextView = itemView.findViewById(R.id.status)
        val phone: TextView = itemView.findViewById(R.id.phone)
        val startLocation: TextView = itemView.findViewById(R.id.startLocation)
        val endLocation: TextView = itemView.findViewById(R.id.endLocation)
        val carType: TextView = itemView.findViewById(R.id.carType)
        val distance: TextView = itemView.findViewById(R.id.distance)
        val email: TextView = itemView.findViewById(R.id.email)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_lay, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
       return bookingList.count()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val dataModel = bookingList[position]
        holder.id.text = dataModel.id.toString()
        holder.name.text = dataModel.name
        holder.bookingDate.text = dataModel.booking_date
        holder.status.text = dataModel.status
        holder.phone.text = dataModel.phone
        holder.startLocation.text = dataModel.start_location
        holder.endLocation.text = dataModel.end_location
        holder.carType.text = dataModel.car_type
        holder.distance.text = dataModel.distance.toString()
        holder.email.text = dataModel.email

    }
}


