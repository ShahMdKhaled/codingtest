package com.noorsoftsolution.chalucholo.data

data class LoginResponse(
    val Result: String,
    val UserID: Int,
    val UserName: String,
    val pening_booking: Int,
    val confirmed_booking: Int,
    val cancelled_booking: Int

)


