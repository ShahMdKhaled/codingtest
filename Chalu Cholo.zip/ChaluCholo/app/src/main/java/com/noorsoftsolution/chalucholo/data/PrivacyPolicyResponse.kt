package com.noorsoftsolution.chalucholo.data

data class PrivacyPolicyResponse(
    val attribute: String,
    val created_at: String,
    val created_user_id: Int,
    val id: Int,
    val updated_at: String,
    val updated_user_id: Int,
    val value: String
)