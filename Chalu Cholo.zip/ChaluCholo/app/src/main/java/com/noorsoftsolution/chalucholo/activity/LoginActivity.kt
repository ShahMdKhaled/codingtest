package com.noorsoftsolution.chalucholo.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.noorsoftsolution.chalucholo.LocalDatabase
import com.noorsoftsolution.chalucholo.R
import com.noorsoftsolution.chalucholo.api.ApiClient
import com.noorsoftsolution.chalucholo.api.ApiService
import com.noorsoftsolution.chalucholo.data.LoginResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class LoginActivity : AppCompatActivity() {

    lateinit var localDatabase: LocalDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        // View গুলোকে ID এর মাধ্যমে খুঁজে বের করা

        val emailEditText: EditText = findViewById(R.id.email)
        val passwordEditText: EditText = findViewById(R.id.password)
        val loginButton: Button = findViewById(R.id.loginButton)



        localDatabase = LocalDatabase(this)


        if (localDatabase != null) {
            val (email, password) = localDatabase.getlogininfo()
            if (email != null && password != null) {
                val intent = Intent(this@LoginActivity, MainActivity::class.java);
                startActivity(intent);

            }
        }

        // Login Button-এ ক্লিক লিসেনার সেট করা
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Input Validation
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both Username and Password", Toast.LENGTH_SHORT)
                    .show()
            } else {


                performLogin(email, password)
            }


        }

    }

    private fun performLogin(email: String, password: String) {
        val apiService = ApiClient.retrofit.create(ApiService::class.java)
        val call = apiService.login(email, password)

        call.enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if (response.isSuccessful) {
                    val loginResponse = response.body()
                    if (loginResponse != null) {

                        localDatabase.logininfo(email, password)
                        val intent = Intent(this@LoginActivity, MainActivity::class.java);
                        startActivity(intent);


                    }
                } else {
                    Toast.makeText(
                        this@LoginActivity,
                        "Login Failed. Please try again.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                Toast.makeText(this@LoginActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })


    }


}