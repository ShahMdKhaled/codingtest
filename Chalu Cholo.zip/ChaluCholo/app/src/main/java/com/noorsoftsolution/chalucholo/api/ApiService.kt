package com.noorsoftsolution.chalucholo.api

import com.noorsoftsolution.chalucholo.data.Booking
import com.noorsoftsolution.chalucholo.data.LoginResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Query

interface ApiService {


    @POST("api/login")
    fun login(
        @Query("email") email: String,
        @Query("password") password: String
    ): Call<LoginResponse>


    @GET("api/logout")
    fun logout(@Header("Authorization") authToken: String): Call<Void>



    @GET("api/booking/pending")
    fun getPendingBookings(@Header("Authorization") authHeader: String): Call<List<Booking>>


    @GET("api/booking/confirm")
    fun getConfirmBookings(@Header("Authorization") authHeader: String): Call<List<Booking>>

    @GET("api/booking/cancel")
    fun getcancelBooking(@Header("Authorization") authHeader: String): Call<List<Booking>>



    @GET("api/company")
    fun getcompany(@Header("Authorization") authHeader: String): Call<List<Booking>>

    @GET("api/app")
    fun getapp(@Header("Authorization") authHeader: String): Call<List<Booking>>

    @GET("api/privacy")
    fun getprivacy(@Header("Authorization") authHeader: String): Call<List<Booking>>

    @GET("api/terms")
    fun getterms(@Header("Authorization") authHeader: String): Call<List<Booking>>



//    @PUT("api/booking/update")
//    fun updateBooking(
//        @Query("id") id: Int,
//        @Query("status") status: String
//    ): Call<UpdateResponse>




}


