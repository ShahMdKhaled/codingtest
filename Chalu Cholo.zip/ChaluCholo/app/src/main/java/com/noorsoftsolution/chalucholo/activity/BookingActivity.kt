package com.noorsoftsolution.chalucholo.activity

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.datepicker.CalendarConstraints
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.textfield.TextInputEditText
import com.noorsoftsolution.chalucholo.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BookingActivity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_booking)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val dateEditText: TextInputEditText = findViewById(R.id.dateEditText)


        // Date Picker Dialog দেখানোর জন্য ক্লিক লিসেনার
        dateEditText.setOnClickListener {

            showDatePicker { selectedDate ->
                dateEditText.setText(selectedDate)
            }
        }
    }


    private fun showDatePicker(onDateSelected: (String) -> Unit) {
        // Date Picker Builder
        val datePicker =
            MaterialDatePicker.Builder.datePicker()
                .setTitleText("Select Date")
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .setCalendarConstraints(
                    CalendarConstraints.Builder()
                        .setStart(System.currentTimeMillis() - (100L * 365 * 24 * 60 * 60 * 1000)) // 100 বছর আগে পর্যন্ত
                        .setEnd(System.currentTimeMillis()) // বর্তমান সময় পর্যন্ত
                        .build()
                )
                .build()

        datePicker.show(supportFragmentManager, "DatePicker")

        // তারিখ সিলেক্ট হলে কলব্যাক
        datePicker.addOnPositiveButtonClickListener { selection ->
            val dateFormatter = SimpleDateFormat("MM/dd/yyyy", Locale.US)
            val date = dateFormatter.format(Date(selection))
            onDateSelected(date)
        }

        // ক্যান্সেল বা বন্ধ হলে Toast দেখানো
        datePicker.addOnNegativeButtonClickListener {
            Toast.makeText(this, "No date selected", Toast.LENGTH_SHORT).show()
        }


}}