package com.noorsoftsolution.chalucholo.activity

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.noorsoftsolution.chalucholo.LocalDatabase
import com.noorsoftsolution.chalucholo.R
import com.noorsoftsolution.chalucholo.adapter.BookingAdapter
import com.noorsoftsolution.chalucholo.api.ApiClient
import com.noorsoftsolution.chalucholo.api.ApiService
import com.noorsoftsolution.chalucholo.data.Booking
import com.noorsoftsolution.chalucholo.data.CompaniResItem
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AboutCompanyActivity : AppCompatActivity() {

    lateinit var localDatabase: LocalDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_about_company)


        localDatabase = LocalDatabase(this)


    }


//    private fun fetchAndDisplayData() {
//        val (email, password) = localDatabase.getlogininfo()
//        val apiService = ApiClient.retrofit.create(ApiService::class.java)
//
//        val authToken = "Basic " + android.util.Base64.encodeToString("$email:$password".toByteArray(),android.util.Base64.NO_WRAP)
//        val call = apiService.getcompany(authToken)
//
//        call.enqueue(object : Callback<List<CompaniResItem>> {
//            override fun onResponse(call: Call<List<CompaniResItem>>, response: Response<List<CompaniResItem>>) {
//                if (response.isSuccessful) {
//                    val aboutDetails = response.body()
//                    if (aboutDetails != null) {
////                        displayData(aboutDetails)
//                    }
//                } else {
//                    Toast.makeText(this@AboutCompanyActivity, "Failed to fetch data.", Toast.LENGTH_SHORT).show()
//                }
//            }
//
//            override fun onFailure(call: Call<List<CompaniResItem>>, t: Throwable) {
//                Toast.makeText(this@AboutCompanyActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
//            }
//        })
//    }
//

}


