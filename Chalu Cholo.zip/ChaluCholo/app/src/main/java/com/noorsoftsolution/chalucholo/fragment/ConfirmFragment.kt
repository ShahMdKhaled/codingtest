package com.noorsoftsolution.chalucholo.fragment

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.noorsoftsolution.chalucholo.LocalDatabase
import com.noorsoftsolution.chalucholo.R
import com.noorsoftsolution.chalucholo.adapter.BookingAdapter
import com.noorsoftsolution.chalucholo.api.ApiClient
import com.noorsoftsolution.chalucholo.api.ApiService
import com.noorsoftsolution.chalucholo.data.Booking
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [ConfirmFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ConfirmFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null


    private lateinit var confirmRec: RecyclerView
    private lateinit var bookingAdapter: BookingAdapter
    lateinit var localDatabase: LocalDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment


        val view =inflater.inflate(R.layout.fragment_confirm, container, false)


        confirmRec = view.findViewById(R.id.confirmRec)
        localDatabase = LocalDatabase(requireContext())

        confirmRec.layoutManager = LinearLayoutManager(requireContext())

        ConfirmData()
        return  view
    }

    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            ConfirmFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }



    private fun ConfirmData() {
        // লোকাল ডাটাবেস থেকে লগইন ইনফরমেশন রিট্রিভ করা
        val (email, password) = localDatabase.getlogininfo()
        val apiService = ApiClient.retrofit.create(ApiService::class.java)

        // বেসিক অথেনটিকেশন হেডার তৈরি করা
        val authToken = "Basic " + android.util.Base64.encodeToString(
            "$email:$password".toByteArray(),
            android.util.Base64.NO_WRAP
        )

        val call = apiService.getConfirmBookings(authToken)
        call.enqueue(object : Callback<List<Booking>> {
            override fun onResponse(call: Call<List<Booking>>, response: Response<List<Booking>>) {
                if (response.isSuccessful) {
                    val dataResponse = response.body()
                    if (dataResponse != null) {

                        var deta= dataResponse.toString()

                        Log.d("dataResponse", dataResponse.toString())
                        bookingAdapter = BookingAdapter(dataResponse)
                        confirmRec.adapter = bookingAdapter

                    }
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Failed to fetch data.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<List<Booking>>, t: Throwable) {
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

}