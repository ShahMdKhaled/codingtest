package com.noorsoftsolution.chalucholo.data

data class Booking(
    val booking_date: String,
    val car_type: String,
    val created_at: String,
    val distance: Double,
    val email: String,
    val end_location: String,
    val fare: Double,
    val id: Int,
    val name: String,
    val phone: String,
    val start_location: String,
    val status: String,
    val updated_at: String,
    val updated_user_id: Any
)
