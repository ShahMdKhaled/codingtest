package com.noorsoftsolution.chalucholo.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.noorsoftsolution.chalucholo.fragment.CancelFragment
import com.noorsoftsolution.chalucholo.fragment.ConfirmFragment
import com.noorsoftsolution.chalucholo.fragment.Pendingfragment

class ViewPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {





    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> Pendingfragment()
            1 -> ConfirmFragment()
            2 -> CancelFragment()
            else -> Pendingfragment()
        }
    }

    override fun getItemCount(): Int {
        return 3
    }


}