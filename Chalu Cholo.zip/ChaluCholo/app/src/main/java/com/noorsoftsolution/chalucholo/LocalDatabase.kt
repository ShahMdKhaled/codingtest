package com.noorsoftsolution.chalucholo

import android.content.Context
import android.content.SharedPreferences

class LocalDatabase (context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)

    // Save data to Shared Preferences
    fun saveData(key: String, value: String) {
        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.apply()
    }

    fun logininfo (email : String, password : String){

        val editor = sharedPreferences.edit()
        editor.putString("email", email)
        editor.putString("password", password)
        editor.apply()
    }

    fun getlogininfo():Pair<String?, String?>{
        val email = sharedPreferences.getString("email", null)
        val password = sharedPreferences.getString("password", null)
        return Pair(email, password)

    }

    // Retrieve data from Shared Preferences
    fun getData(key: String): String? {
        return sharedPreferences.getString(key, null) // Returns null if key doesn't exist
    }


    fun clearLoginInfo() {
        val editor = sharedPreferences.edit()
        editor.remove("email")
        editor.remove("password")
        editor.apply()
    }


    // Clear all data in Shared Preferences
    fun clearData() {
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }

    // Remove specific data in Shared Preferences
    fun removeData(key: String) {
        val editor = sharedPreferences.edit()
        editor.remove(key)
        editor.apply()
    }

}